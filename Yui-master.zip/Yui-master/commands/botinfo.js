const Discord = require("discord.js");
const moment = require("moment");
const ping = require("ping");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    ping.promise.probe('discordapp.com').then(result => {

        let package = require("../package.json");

        let t = new Date(bot.uptime);

        let months = t.getUTCMonth();
        let days = t.getUTCDate() - 1;

        let minutes = t.getUTCMinutes();
        let hours = t.getUTCHours();


        let seconds = t.getUTCSeconds();

        let uptime = `**${months}**mo, **${days}**d, **${hours}**h, **${minutes}**m, **${seconds}**s`;

        var successEmbed = new Discord.RichEmbed()

            .setColor(message.vars.embedRandom)
            .setTitle(`Informations about ${bot.user.username}`)
            .setThumbnail(message.vars.YuiLogo)
            .setTimestamp()
            .addField("Name + Tag", `**${bot.user.username}**#${bot.user.discriminator}`, true)
            .addField("Client ID", `${bot.user.id}`, true)
            .addField("Developer", `**${message.guild.member(BotSettings.OwnerID).user.username}**#${message.guild.member(BotSettings.OwnerID).user.discriminator}`, true)
            .addField(`Prefix`, `The prefix of the bot is **${BotSettings.prefix}**`, true)
            .addField("Library", "[discord.js](https://discord.js.org/#/)", true)
            .addField("Coding Software", "[Visual Studio Code](https://code.visualstudio.com/)", true)
            .addField("Ping", `discordapp.com: **${result.time}**ms \nDiscord API: **${Math.round(bot.ping)}**ms`, true)
            .addField("Uptime", `${uptime}`, true)
            .addField("Channels", `**${bot.channels.size}** Total Channels! \n**${bot.channels.filter(channels => channels.type == "category").size}** Categories! \n**${bot.channels.filter(channels => channels.type == "text").size}** Text-Channels! \n**${bot.channels.filter(channels => channels.type == "voice").size}** Voice-Channels!`, true)
            .addField("Guilds & Users", `**${bot.guilds.size}** guilds! \n**${bot.users.size}** users!`, true)
            .addField("Status", `${BotSettings.Usertypes[bot.user.presence.status]}`, true)
            .addField("Created At", `${moment(bot.user.createdAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true)
            .addField(`Joined this Server: "${message.guild.name}" on`, `${moment(message.guild.joinedAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true);

        message.channel.send(successEmbed);
    });
};

module.exports.help = {
    name: "botinfo",
    desc: "This command gives you Informations about the bot.\n \nAs an example, the uptime or the creation date from the bot.",
    usage: "None",
    perms: "None"
};