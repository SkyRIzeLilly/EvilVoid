const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.author.id === BotSettings.OwnerID) {

        if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a role.");

        var Rolle = message.guild.roles.find(role => role.name === message.args.join(" "));

        if (Rolle) {
            var successEmbed = new Discord.RichEmbed()
                .setColor(message.guild.roles.find(role => role.name === message.args.join(" ")).hexColor || message.vars.YuiRandom)
                .setDescription(`You have been removed from the role ${Rolle}.`);

            if (message.member.roles.has(Rolle.id)) {
                message.member.removeRole(Rolle.id)
                    .then(message.channel.send(successEmbed)).catch(error => {
                        Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
                    });
            } else if (!message.member.roles.has(Rolle.id)) return Embeds.error(message.channel, "You are not assigned to the role, you want to remove yourself.");
        } else if (!message.guild.roles.find(role => role.name === Rolle)) Embeds.error(message.channel, "This role does not exist on the server.");
    } else {
        let msgremove = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgremove.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "removerole",
    desc: "Removes you a role of your choice.\n \nRemember, that the bot is above the role \nyou want to remove yourself.",
    usage: "removerole [role]",
    perms: "Developer Perms"
};