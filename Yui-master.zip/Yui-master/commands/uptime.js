const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    let t = new Date(bot.uptime);

    let months = t.getUTCMonth();
    let days = t.getUTCDate() - 1;

    let minutes = t.getUTCMinutes();
    let hours = t.getUTCHours();


    let seconds = t.getUTCSeconds();


    let uptime = `**${months}** months, **${days}** days, **${hours}** hours, **${minutes}** minutes and **${seconds}** seconds`;

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setDescription(`Online since ${uptime}`)
        .setTimestamp();

    if (message.args.join(" ") == 0) {
        if (message.author.id === BotSettings.OwnerID) {
            bot.users.get(BotSettings.OwnerID).send(message.author, successEmbed);
        } else {
            let msgup = await Embeds.dev(message.channel);
            setTimeout(async () => {
                msgup.delete();
            }, 5000);
        }
        message.delete();
    };

    if (message.args.join(" ") === "channel") {
        if (message.author.id === BotSettings.OwnerID) {
            message.channel.send(successEmbed);
        } else {
            let msgup = await Embeds.dev(message.channel);
            setTimeout(async () => {
                msgup.delete();
            }, 5000);
        }
    }
};

module.exports.help = {
    name: "uptime",
    desc: "This command shows you the uptime of the bot.",
    usage: "None",
    perms: "Developer Perms"
};