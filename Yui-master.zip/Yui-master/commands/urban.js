const Discord = require("discord.js");
const urban = require("urban");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a definition.");
    let str = message.args.join(" ");

    urban(str).first(json => {
        if (!json) return Embeds.error(message.channel, "No results found!");

        var successEmbed = new Discord.RichEmbed()
            .setColor(message.vars.embedRandom)
            .setTitle(json.word)
            .setDescription(json.definition)
            .setFooter(`Written by ${json.author}`)
            .addField("Upvotes", json.thumbs_up, true)
            .addField("Downvotes", json.thumbs_down, true);

        message.channel.send(successEmbed);
    });
};

module.exports.help = {
    name: "urban",
    desc: "Grabs a definition from the urban dictonary.",
    usage: "None",
    perms: "None"
};