const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a server.");
    if (!message.guild.member("525633041633247262").hasPermission("CREATE_INSTANT_INVITE")) return Embeds.error(message.channel, "I do not have permissions to create an Invite on this guild.");
    if (!bot.guilds.find(server => server.name === message.args.join(" "))) return Embeds.error(message.channel, "I can't find this guild.");

    if (message.author.id === BotSettings.OwnerID) {
        bot.guilds.get(bot.guilds.find(server => server.name === message.args.join(" ")).id).channels.filter(channels => channels.type == "text").first().createInvite().then(invite => {
            var successEmbed = new Discord.RichEmbed()
                .setColor(message.vars.embedRandom)
                .setDescription(`I created an Invite for the server: **${message.args.join(" ")}**\n \n\n${invite.url}`);

            if (bot.guilds.find(server => server.name == message.args.join(" ")).iconURL) {
                successEmbed.setThumbnail(bot.guilds.find(server => server.name === message.args.join(" ")).iconURL);
            }

            message.channel.send(successEmbed);
        });


    } else {
        let msginv = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msginv.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "guildinvite",
    desc: "Creates an Invite for the server you enter.",
    usage: "None",
    perms: "Developer Perms"
};