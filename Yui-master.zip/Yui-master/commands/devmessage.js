const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setDescription("Your message was sent to the Developer.");

    let DevEmbedSuccess = new Discord.RichEmbed()

        .setColor(message.vars.embedRandom)
        .setAuthor(message.vars.NewtoxName, message.vars.NewtoxLogo)
        .setTitle(`${message.vars.AuthorName} used the Devmessage Command!`)
        .setDescription(message.args.join(" "))
        .setThumbnail(message.vars.AuthorLogo)
        .setFooter(message.vars.YuiName, message.vars.YuiLogo)
        .setTimestamp();

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a full message.");

    bot.users.get(BotSettings.OwnerID).send(DevEmbedSuccess);
    let msgdev = await message.channel.send(successEmbed);
    setTimeout(async () => {
        msgdev.delete();
    }, 3000);

};

module.exports.help = {
    name: "devmessage",
    desc: "Sends a message to the developer of this bot. \nSo if you found any Bugs, just report these. Or you can submit suggestions.",
    usage: "None",
    perms: "None"
};