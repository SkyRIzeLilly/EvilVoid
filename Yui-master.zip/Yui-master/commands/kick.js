const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
  message.delete();
  let BotSettings = bot.settings;
  let Embeds = bot.embeds;

  try {
    if (message.author.id === BotSettings.OwnerID || message.member.hasPermission("KICK_MEMBERS")) {

      let member = message.mentions.members.first() || message.guild.members.get(message.args[0]);

      if (!message.guild.member(bot.user.id).hasPermission("KICK_MEMBERS")) return Embeds.error(message.channel, "I do not have permissions to kick members on this guild.");

      if (!member) return Embeds.missing(message.channel, "Please enter a member that is on the server.");

      if (member.hasPermission("ADMINISTRATOR") || member.hasPermission("KICK_MEMBERS")) return Embeds.error(message.channel, "This member is not kickable!");

      let reason = message.args.slice(1).join(" ");

      if (!reason) return Embeds.missing(message.channel, "Please give a reason!");

      if (member.id === BotSettings.OwnerID) return Embeds.error(message.channel, "The Developer cannot be kicked!");

      await member.kick({
        reason: reason
      });

      var successEmbed = new Discord.RichEmbed()

        .setColor(message.vars.embedRandom)
        .setDescription(`**${member.user.username}**#${member.user.discriminator} was kicked off the server for **${reason}**`);

      message.channel.send(successEmbed);
    } else {
      Embeds.error(message.channel, "This command requires the following server rights: **Kick_Members**.")
    }
  } catch (error) {
    Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
  }
};

module.exports.help = {
  name: "kick",
  desc: "With this command you can kick a member of this server, as long as you and I have the permission to execute this action. \nRemember that i can't kick a member with a role equal or higher than my highest role.",
  usage: "kick [member/ID] [reason]",
  perms: "Kick_Members"
};