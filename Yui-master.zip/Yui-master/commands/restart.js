const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setDescription("Restart was successful!");

    if (message.author.id === BotSettings.OwnerID) {

        let restartchannel = message.channel;

        restartchannel.send(`Restarting...`);
        bot.destroy()
            .then(bot.login(BotSettings.token).then(async () => restartchannel.send(message.author, successEmbed)));

    } else {
        let msgrt = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgrt.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "restart",
    desc: "The bot will restart.",
    usage: "None",
    perms: "Developer Perms"
};