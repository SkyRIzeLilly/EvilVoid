const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    var successEmbed = new Discord.RichEmbed()
        
        .setColor(message.vars.embedRandom)
        .setTitle(`Hey, I was programmed by ${message.vars.NewtoxName}`)
        .setTimestamp()
        .addField(`Invite (All Permissions)`, `[Click here!](${await bot.generateInvite(2146958847)})`)
        .addField(`Invite (Core Permissions)`, `[Click here!](${await bot.generateInvite(51264)})`)
        .addField(`Invite (No Permissions)`, `[Click here!](${await bot.generateInvite()})`)
        .addField(`Support Server`, `[Click here!](https://discord.gg/ahsYMMq)`)
        .addField(`Github-Repository`, `[Click here!](https://github.com/Newtox/Yui)`);

        message.channel.send(successEmbed);
}

module.exports.help = {
    name: "bothelp",
    desc: "This command gives you some additional information for this bot.\n \nAs an example, invite links and source code.",
    usage: "None",
    perms: "None"
};