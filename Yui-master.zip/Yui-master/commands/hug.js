const Discord = require("discord.js");
const client = require("nekos.life");
const nekos = new client;


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    const redirect = await nekos.sfw.hug().then(res => res.url)

    const target = message.mentions.members.first() || message.guild.members.get(message.args[0])

    if (!target) return Embeds.missing(message.channel, "Please enter a member.");

    if (target == message.member) return Embeds.error(message.channel, `Uhm, ${message.member}, you cannot hug yourself.`);

    var successEmbed = new Discord.RichEmbed()

        .setColor(message.vars.embedRandom)
        .setDescription(`${message.member} is hugging ${target}`)
        .setImage(redirect);

    message.channel.send(successEmbed)
};

module.exports.help = {
    name: "hug",
    desc: "Command should explain itself.",
    usage: "hug [member/ID]",
    perms: "None"
};