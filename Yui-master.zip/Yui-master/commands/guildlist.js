const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    let compare = (a, b) => {
        if (a.position > b.position) return -1;
        if (a.position < b.position) return 1;
        return 0;
    }

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setTitle(`Members | Server | ID`)
        .setDescription(`The bot is active on **${bot.guilds.size}** Servers: \n \n${bot.guilds.sort(compare).map(servers => `(${servers.members.size})` + " " + `${servers}` + " " + `(${servers.id})`).join(",\n")}`)
        .setTimestamp();

    if (message.args.join(" ") == 0) {
        if (message.author.id === BotSettings.OwnerID) {
            bot.users.get(BotSettings.OwnerID).send(message.author, successEmbed);
        } else {
            let msglist = await message.channel.send(message.author, DevEmbed);
            setTimeout(async () => {
                msglist.delete();
            }, 5000);
        }
        message.delete();
    }

    if (message.args.join(" ") === "channel") {
        if (message.author.id === BotSettings.OwnerID) {
            message.channel.send(successEmbed);
        } else {
            let msglist = await Embeds.dev(message.channel);
            setTimeout(async () => {
                msglist.delete();
            }, 5000);
        }
    }
};

module.exports.help = {
    name: "guildlist",
    desc: "Lists all servers on which the bot is located.",
    usage: "None",
    perms: "Developer Perms"
};