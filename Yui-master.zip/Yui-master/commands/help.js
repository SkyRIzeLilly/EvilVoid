const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    console.log(message.args);

    if (message.args != [] && message.args[0]) {
        if (bot.commands.has(message.args[0])) {
            var commandInfo = bot.commands.get(message.args[0]).help
            if (commandInfo.usage === "None") {
                let CmdEmbed = new Discord.RichEmbed()

                    .setColor(message.vars.embedRandom)
                    .setFooter("Help")
                    .setTitle(commandInfo.name)
                    .addField(`Command Description`, `\`\`\`${commandInfo.desc}\`\`\``)
                    .addField(`Command Usage`, `\`\`${commandInfo.usage}\`\``, true)
                    .addField(`Required Permissions`, `**${commandInfo.perms}**`, true);

                message.channel.send(CmdEmbed);
            } else {
                let CmdEmbed = new Discord.RichEmbed()

                    .setColor(message.vars.embedRandom)
                    .setFooter("Help")
                    .setTitle(commandInfo.name)
                    .addField(`Command Description`, `\`\`\`${commandInfo.desc}\`\`\``)
                    .addField(`Command Usage`, `\`\`${BotSettings.prefix}${commandInfo.usage}\`\``, true)
                    .addField(`Required Permissions`, `**${commandInfo.perms}**`, true);

                message.channel.send(CmdEmbed);
            }
        } else if (!bot.commands.has(message.args[0])) {
            message.delete();

            let ErrorCmd = new Discord.RichEmbed()
                .setColor("#a21018")
                .setTitle("Command execution failed.")
                .setDescription("This command does not exist.");

            let msgcmd = await message.channel.send(message.author, ErrorCmd);
            setTimeout(async () => {
                msgcmd.delete();
            }, 5000);
        }
    } else {
        var successEmbed = new Discord.RichEmbed()

        successEmbed.setColor(message.vars.embedRandom)
        successEmbed.setTitle(`Use \`\`${BotSettings.prefix}help [command]\`\` to get more details about a specific command.`)
        successEmbed.setThumbnail(message.vars.YuiLogo)
        successEmbed.setFooter(message.vars.AuthorName, message.vars.AuthorLogo)
        successEmbed.setTimestamp()
        successEmbed.addField("Info", "`bothelp`, `botinfo`, `channelinfo`, `emojiinfo`, `emojilist`, `rolecolor`, `roleinfo`, `rolelist`, `serverinfo`, `urban`, `urbanrandom`, `userinfo`", false)
        successEmbed.addField("Moderation", "`ban`, `clear`, `kick`", false)
        successEmbed.addField("Roleplay", "`baka`, `hug`, `kiss`, `pat`, `poke`, `slap`, `tickle`", false)
        successEmbed.addField("No Category", "`devmessage`, `emoji`, `usermessage`", false)
        successEmbed.addField("Developer", "`addrole`, `botpermissions`, `eval`, `guildinvite`, `guildleave`, `guildlist`, `ping`, `refresh`, `removerole`, `restart`, `say`, `status`, `uptime`", false);

        message.channel.send(successEmbed);
    }
};

module.exports.help = {
    name: "help",
    desc: "Shows help",
    usage: "None",
    perms: "None"
};