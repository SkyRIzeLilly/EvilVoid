const Discord = require("discord.js");
const urban = require("urban");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    urban.random().first(json => {

        var successEmbed = new Discord.RichEmbed()
            .setColor(message.vars.embedRandom)
            .setTitle(json.word)
            .setDescription(json.definition)
            .setFooter(`Written by ${json.author}`)
            .addField("Upvotes", json.thumbs_up, true)
            .addField("Downvotes", json.thumbs_down, true);

        message.channel.send(successEmbed);
    });
};

module.exports.help = {
    name: "urbanrandom",
    desc: "Grabs a random definition from the Urban Dictonary.",
    usage: "None",
    perms: "None" 
};