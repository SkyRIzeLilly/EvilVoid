const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setDescription(`Status Presence changed to **${message.args.join(" ")}**`);

    if (message.author.id === BotSettings.OwnerID) {
        if (message.args.join(" ") == 0) return Embeds.missing(message.channel, "Please enter a Type \n`online, dnd, idle, invisible`");
        if (message.args.join(" ") == "online") {
            bot.user.setStatus("online")
            message.channel.send(successEmbed);

        } else if (message.args.join(" ") == "dnd") {
            bot.user.setStatus("dnd")
            message.channel.send(successEmbed);

        } else if (message.args.join(" ") == "idle") {
            bot.user.setStatus("idle")
            message.channel.send(successEmbed);

        } else if (message.args.join(" ") == "invisible") {
            bot.user.setStatus("invisible")
            message.channel.send(successEmbed);
        }
    } else {
        let msgst = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgst.delete();
        }, 5000);
    }
    message.delete();
};

module.exports.help = {
    name: "status",
    desc: "Change the status type from the bot.",
    usage: "None",
    perms: "Developer Perms"
};