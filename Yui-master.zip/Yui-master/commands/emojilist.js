const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (!message.guild.iconURL) return Embeds.missing(message.channel, "If you want to execute this command, the server will need an icon.");

    let compare = (a, b) => {
        if (a.position > b.position) return -1;
        if (a.position < b.position) return 1;
        return 0;
    }

    var successEmbed = new Discord.RichEmbed()

        .setColor(message.vars.embedRandom)
        .setTitle(`Emojis listed from ${message.guild.name}\nTotal Emojis: ${message.guild.emojis.size}\n`)
        .setDescription(`\n${message.guild.emojis.sort(compare).map(emojis => `${emojis}`).join("").substr(0, 2000)}`)
        .setFooter(message.guild.name, message.guild.iconURL)
        .setTimestamp();

    message.channel.send(successEmbed);
};

module.exports.help = {
    name: "emojilist",
    desc: "Lists all emojis of the server.",
    usage: "None",
    perms: "None"
};