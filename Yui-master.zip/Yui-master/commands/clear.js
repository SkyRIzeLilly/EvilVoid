const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;


    if (message.author.id === BotSettings.OwnerID || message.member.hasPermission("MANAGE_MESSAGES")) {

        if (!message.guild.member(bot.user.id).hasPermission("MANAGE_MESSAGES")) return Embeds.error(message.channel, "I do not have permissions to delete messages on this guild.");

        let deleteCount = parseInt(message.args[0], 10);

        if (!deleteCount || deleteCount < 2 || deleteCount > 99) return Embeds.missing(message.channel, "Please enter a number between **2** and **100**.");

        let deleted = await message.channel.bulkDelete(deleteCount + 1).catch(error => {
            Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
        });

        var successEmbed = new Discord.RichEmbed()

            .setColor(message.vars.embedRandom)
            .setDescription(`**${deleted.size}** messages have been deleted.`);

        let msgclear = await message.channel.send(successEmbed);
        setTimeout(async () => {
            msgclear.delete();
        }, 3000);

    } else {
        Embeds.error(message.channel, "This command requires the following server rights: **Manage_Messages**.");
    }
};

module.exports.help = {
    name: "clear",
    desc: "With this command you can delete messages from your current text channel.\nRemember that I can't delete messages that are older than 2 weeks.",
    usage: "clear [number]",
    perms: "Manage_Messages"
};