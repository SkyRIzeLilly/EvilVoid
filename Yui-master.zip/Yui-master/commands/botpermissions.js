const Discord = require("discord.js");


module.exports.run = async (bot, message, args) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    var result = "";
    Object.entries(Discord.Permissions.FLAGS).forEach(element => {
        console.log(message)
        result += `${(message.guild.me.hasPermission(element[0]) ? bot.emojis.get("520652527906193419") : bot.emojis.get("520652786803933185"))} ${element[0]}\n`
    });

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setTitle(`${bot.user.username}'s Permissions on ${message.guild.name}`)
        .setDescription(result)
        .setTimestamp();


    if (message.args.join(" ") == 0) {
        if (message.author.id === BotSettings.OwnerID) {
            bot.users.get(BotSettings.OwnerID).send(message.author, successEmbed);
        } else {
            let msgbot = await message.channel.send(message.author, DevEmbed);
            setTimeout(async () => {
                msgbot.delete();
            }, 5000);
        }
    }
    if (message.args.join(" ") == "channel") {
        if (message.author.id === BotSettings.OwnerID) {
            message.channel.send(successEmbed);
        } else {
            let msgbot = await Embeds.dev(message.channel);
            setTimeout(async () => {
                msgbot.delete();
            }, 5000);
        }
    }
};

module.exports.help = {
    name: "botpermissions",
    desc: "This command shows you the permissions from the bot.",
    usage: "None",
    perms: "Developer Perms"
};