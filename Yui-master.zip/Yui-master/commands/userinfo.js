const Discord = require("discord.js");
const moment = require("moment");
const ping = require("ping");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    let compare = (a, b) => {
        if (a.position > b.position) return -1;
        if (a.position < b.position) return 1;
        return 0;
    }

    try {

        const target = message.mentions.members.first() || message.guild.members.get(message.args[0]) || message.member;

        let result = [];

        Object.entries(Discord.Permissions.FLAGS).forEach(element => {
            if (target.hasPermission(element[0])) {
                result += `\`\`${element[0].toLowerCase()}\`\`, `
            }
        });

        if (target) {
            var successEmbed = new Discord.RichEmbed()


                .setColor(target.highestRole.color || message.vars.embedRandom)
                .setThumbnail(`${target.user.displayAvatarURL}`)
                .setAuthor(`Userinfo about ${target.user.username}`)

            if (target.user.bot) {
                successEmbed.setTitle(`:robot: This is a bot account`);
            }

            successEmbed.setFooter(message.guild.name)
            successEmbed.setTimestamp()

            successEmbed.addField(`Name + Tag`, `**${target.user.username}**#${target.user.discriminator}`)

            if (target.user.username != target.displayName) {
                successEmbed.addField(`Nickname`, `**${target.displayName}**`);
            } else {
                successEmbed.addField(`Nickname`, `-`);
            }

            successEmbed.addField(`ID`, `\`\`\`${target.id}\`\`\``, true);

            successEmbed.addField(`Status`, `${BotSettings.Usertypes[target.presence.status]}`);

            if (target.presence.game) {
                successEmbed.addField(`Activity`, `${BotSettings.Activitytypes[target.user.presence.game.type]} **${target.user.presence.game.name}**`);
            } else {
                successEmbed.addField(`Activity`, `-`);
            }

            successEmbed.addField(`Roles`, `${target.roles.sort(compare).map(roles => roles).join(", ").substr(0, 900) || `-`}`);

            successEmbed.addField(`Permissions`, result.substr(0, 1000));

            successEmbed.addField(`Account creation date`, `${moment(target.user.createdAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, false);

            successEmbed.addField(`Server Joindate`, `${moment(target.joinedAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, false);

            successEmbed.addField(`Avatar`, `[Click here to download the Avatar!](${target.user.displayAvatarURL})`);

            message.channel.send(successEmbed);
        }
    } catch (error) {
        Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
    }
};


module.exports.help = {
    name: "userinfo",
    desc: "This command gives you some information about your account.\n \nIf you want to know some Information about another user\nJust mention the user you want to know something from.",
    usage: "userinfo / [member] / [ID]",
    perms: "None"
};