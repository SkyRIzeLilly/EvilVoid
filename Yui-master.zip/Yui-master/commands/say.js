const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.author.id === BotSettings.OwnerID) {
        var Say = message.args.join(" ");
        if (Say) {
            message.channel.send(Say);
        } else {
            Embeds.missing(message.channel, "What do you want me to say?");
        }
    } else {
        let msgsay = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgsay.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "say",
    desc: "Command should explain itself.",
    usage: "say [arguments]",
    perms: "Developer Perms"
};