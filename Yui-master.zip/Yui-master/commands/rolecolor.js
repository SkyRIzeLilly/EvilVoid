const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter an available role.");

    var Rolle = message.args.join(" ");

    if (Rolle) {

        if (message.guild.roles.find(role => role.name === Rolle)) {

            var successEmbed = new Discord.RichEmbed()
                .setColor(message.guild.roles.find(role => role.name === Rolle).hexColor)
                .setDescription(`The role ${message.guild.roles.find(role => role.name === Rolle)} has the hex-color **${message.guild.roles.find(role => role.name === Rolle).hexColor.toLowerCase()}**.`);

            message.channel.send(successEmbed);
        } else {
            Embeds.error(message.channel, "This is not a role that exists on the server.");
        }
    }
    return
};

module.exports.help = {
    name: "rolecolor",
    desc: "This command gives you the hex code of a specific role.",
    usage: "rolecolor [Rolename]",
    perms: "None"  
};