const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.author.id === BotSettings.OwnerID) {
        let command = message.args.join(" ");

        try {
            if (command.includes("BotSettings.token")) return Embeds.error(message.channel, "token is blacklisted.");
            let evaled = await eval(command);
            var successEmbed = new Discord.RichEmbed()

                .setColor(message.vars.embedRandom)
                .setTitle("eval was successfully executed!")
                .setDescription("```" + evaled + "```")
                .setTimestamp();

            message.channel.send(successEmbed);
        } catch (error) {
            Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
        }
    } else {
        let msgeval = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgeval.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "eval",
    desc: "With this command you can eval js code.",
    usage: "None",
    perms: "Developer Perms"
};