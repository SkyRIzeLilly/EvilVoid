const Discord = require("discord.js");
const moment = require("moment");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (!message.guild.iconURL) return Embeds.missing(message.channel, "If you want to execute this command, the server will need an icon.");

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a channel.");

    var Channel = message.args.join(" ");

    if (Channel) {

        if (message.guild.channels.find(channel => channel.name === Channel)) {

            var successEmbed = new Discord.RichEmbed()


                .setColor(message.vars.embedRandom)
                .setFooter(message.guild.name, message.guild.iconURL)
                .setTimestamp()
                .addField("Name", `${message.guild.channels.find(channel => channel.name === Channel)}`, true)
                .addField("ID", `*${message.guild.channels.find(channel => channel.name === Channel).id}*`, true)
                .addField("Created at", `${moment(message.guild.channels.find(channel => channel.name === Channel).createdAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, false);

            message.channel.send(successEmbed);

        } else {
            Embeds.error(message.channel, "This channel does not exist on the server.");
        }
    }
};

module.exports.help = {
    name: "channelinfo",
    desc: "This command gives you Informations about a specific channel.",
    usage: "channelinfo [channelname]",
    perms: "None"
};