const Discord = require("discord.js");
const moment = require("moment");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (!message.guild.iconURL) return Embeds.missing(message.channel, "If you want to execute this command, the server will need an icon.");

    let compare = (a, b) => {
        if (a.position > b.position) return -1;
        if (a.position < b.position) return 1;
        return 0;
    }

    var successEmbed = new Discord.RichEmbed()

    .setColor(message.vars.embedRandom)
    .setTitle(`${message.guild.name}`, true)
    .setThumbnail(`${message.guild.iconURL}`)
    .setFooter(message.vars.YuiName, message.vars.YuiLogo)
    .setTimestamp()
    .addField(`Name | ID`, `${message.guild.name} | ${message.guild.id}`, false)
    .addField(`Owner`, `${message.guild.owner} | ${message.guild.ownerID}`)
    .addField(`Information`, `Region: **${message.guild.region}** \nVerification Level: **${BotSettings.Verification_Name[message.guild.verificationLevel]}**\nTotal Members: **${message.guild.members.size}**\nHumans: **${message.guild.members.filter(members => !members.user.bot).size}**\nBots: **${message.guild.members.filter(members => members.user.bot).size}**\nTotal Channels: **${message.guild.channels.size}**\nCategories: **${message.guild.channels.filter(channels => channels.type == "category").size}**\nText-Channels: **${message.guild.channels.filter(channels => channels.type == "text").size}**\nVoice-Channels: **${message.guild.channels.filter(channels => channels.type == "voice").size}**\nAFK-Channel: **${message.guild.afkChannel}**`, true)
    .addField(`Member Information`, `<:online:507524731927396380> Online **${message.guild.members.filter(mem => mem.user.presence.status && mem.user.presence.status === 'online').size}**\n<:idle:507524745378398210> Idle **${message.guild.members.filter(mem => mem.user.presence.status && mem.user.presence.status === 'idle').size}**\n<:dnd:507524739582001178> Do Not Disturb **${message.guild.members.filter(mem => mem.user.presence.status && mem.user.presence.status === 'dnd').size}**\n<:offline:507524756627652613> Offline **${message.guild.members.filter(mem => mem.user.presence.status && mem.user.presence.status === 'offline').size}**`, true)
    .addField(`Roles`, `The server has **${message.guild.roles.size}** Roles -> \`${BotSettings.prefix}rolelist\``, false)
    .addField(`Emojis`, `The server has **${message.guild.emojis.size}** Emojis -> \`${BotSettings.prefix}emojilist\``, false)
    .addField(`Server creation date`, `${moment(message.guild.createdAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true)
    .addField(`Server Icon`, `[Click here to download the server icon!](${message.guild.iconURL})`, false);
   
    message.channel.send(successEmbed);
};

module.exports.help = {
    name: "serverinfo",
    desc: "This command gives you informations about this server.",
    usage: "None",
    perms: "None"
};