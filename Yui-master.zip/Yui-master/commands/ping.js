const Discord = require("discord.js");
const ping = require("ping");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;
    
    if (message.args.join(" ") == 0) {
        if (message.author.id === BotSettings.OwnerID) {
            ping.promise.probe('discordapp.com').then(result => {

                var successEmbed = new Discord.RichEmbed()
                    .setColor(message.vars.embedRandom)
                    .setTitle(`${bot.user.username}'s Ping!`)
                    .setDescription(`discordapp.com: **${result.time}**ms \nDiscord API: **${Math.round(bot.ping)}**ms`)
                    .setTimestamp();

                bot.users.get(BotSettings.OwnerID).send(message.author, successEmbed);
            });
        } else {
            let msgpi = await Embeds.dev(message.channel);
            setTimeout(async () => {
                msgpi.delete();
            }, 5000);
        }
        message.delete();

    }
    if (message.args.join(" ") === "channel") {
        if (message.author.id === BotSettings.OwnerID) {
            ping.promise.probe('discordapp.com').then(result => {

                var successEmbed = new Discord.RichEmbed()
                    .setColor(message.vars.embedRandom)
                    .setTitle(`${bot.user.username}'s Ping!`)
                    .setDescription(`discordapp.com: **${result.time}**ms \nDiscord API: **${Math.round(bot.ping)}**ms`)
                    .setTimestamp();

                message.channel.send(successEmbed);
            });
        } else {
            let msgpi = await Embeds.dev(message.channel);
            setTimeout(async () => {
                msgpi.delete();
            }, 5000);
        }
    }
};

module.exports.help = {
    name: "ping",
    desc: "Check the latency from the bot.",
    usage: "None",
    perms: "Developer Perms"
};