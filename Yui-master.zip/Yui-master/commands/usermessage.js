const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    try {
        const target = message.mentions.members.first() || message.guild.members.get(message.args[0]);
        message.args.shift();

        if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a full message.");

        let userembed = new Discord.RichEmbed()

            .setColor(message.vars.embedRandom)
            .setAuthor(target.user.tag, target.user.displayAvatarURL)
            .setTitle(`You recieved a message from ${message.author.username}#${message.author.discriminator}`)
            .setDescription(message.args.join(" "))
            .setThumbnail(message.vars.AuthorLogo)
            .setFooter(message.guild.name, message.vars.YuiLogo)
            .setTimestamp();


        bot.users.get(target.id).send(userembed);

        var successEmbed = new Discord.RichEmbed()
            .setColor(message.vars.embedRandom)
            .setDescription(`Your message was sent to **${target.user.username}**#${target.user.discriminator}.`);

        let msguser = await message.channel.send(successEmbed);
        setTimeout(async () => {
            msguser.delete();
        }, 3000);

    } catch (error) {
        Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
    }
};

module.exports.help = {
    name: "usermessage",
    desc: "I will send your message to a specific member.",
    usage: "usermessage / [member] / [ID]",
    perms: "None"
};