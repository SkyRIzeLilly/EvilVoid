const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter an emoji.");

    let Emote = message.args[0];

    if (Emote) {

        if (message.guild.emojis.find(emoji => emoji.name === Emote)) {

            var successEmbed = new Discord.RichEmbed()
                .setColor(message.vars.embedRandom)
                .setDescription(`Here is the emoji **${Emote}**.\n \n[Click here to download the emoji.](${message.guild.emojis.find(emoji => emoji.name === Emote).url})`)
                .setThumbnail(message.guild.emojis.find(emoji => emoji.name === Emote).url)
                .setTimestamp();

            message.channel.send(successEmbed);

        } else if (!message.guild.emojis.find(emoji => emoji.name === Emote)) {
            Embeds.error(message.channel, "This is not an emoji that exists on the server.");
        }
    }
    return
};

module.exports.help = {
    name: "emoji",
    desc: "This command gives you a specific emoji as a file. \nThe emoji does not have to be used, just enter the name of the emoji.",
    usage: "emoji [emojiname]",
    perms: "None"
};