const Discord = require("discord.js");
const {
    exec
} = require('child_process');


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (message.author.id === BotSettings.OwnerID) {
        exec("git pull", (err, out, stderr) => {
            if (!err) {
                exec("pm2 restart toxbot", (err, out, stderr) => {
                    bot.users.get(BotSettings.OwnerID).send(err, out, stderr);
                    console.log(err, out, stderr);
                });
            } else {
                console.log("Update failed", err, out, stderr);
            };
        });
    } else {
        let msgref = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgref.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "refresh",
    desc: "This Command wil update the other commands.",
    usage: "None",
    perms: "Developer Perms"
};