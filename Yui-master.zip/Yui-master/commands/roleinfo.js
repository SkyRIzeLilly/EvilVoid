const Discord = require("discord.js");
const moment = require("moment");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (!message.guild.iconURL) return Embeds.missing(message.channel, "If you want to execute this command, the server will need an icon.");

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a role.");

    var Rolle = message.args.join(" ");

    if (Rolle) {

        if (message.guild.roles.find(role => role.name === Rolle)) {

            var successEmbed = new Discord.RichEmbed()


                .setColor(message.guild.roles.find(role => role.name === Rolle).hexColor)
                .setFooter(message.guild.name, message.guild.iconURL)
                .setTimestamp()
                .addField("Name", `${message.guild.roles.find(role => role.name === Rolle)}`, true)
                .addField("ID", `*${message.guild.roles.find(role => role.name === Rolle).id}*`, true)
                .addField("Position", `${message.guild.roles.size - message.guild.roles.find(role => role.name === Rolle).position}`, true)
                .addField("Members in Role", `${message.guild.roles.find(role => role.name === Rolle).members.size}`, true)
                .addField("Color", `${message.guild.roles.find(role => role.name === Rolle).hexColor}`, true);

            if (message.guild.roles.find(role => role.name === Rolle).mentionable) {
                successEmbed.addField("Mentionable", "Yes", true);
            } else {
                successEmbed.addField("Mentionable", "No", true);
            }

            if (message.guild.roles.find(role => role.name === Rolle).hoist) {
                successEmbed.addField("Hoisted (Displayed seperately)", "Yes", true);
            } else {
                successEmbed.addField("Hoisted (Displayed seperately)", "No", true);
            }

            if (message.guild.roles.find(role => role.name === Rolle).managed) {
                successEmbed.addField("Managed (Bot Role)", "Yes", true);
            } else {
                successEmbed.addField("Managed (Bot Role)", "No", true);
            }

            successEmbed.addField("Created at", `${moment(message.guild.roles.find(role => role.name === Rolle).createdAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true)

            message.channel.send(successEmbed);

        } else {
            Embeds.error(message.channel, "This role does not exist on the server.");
        }
    }
};

module.exports.help = {
    name: "roleinfo",
    desc: "This command gives you Informations about a specific role.",
    usage: "roleinfo [Rolename]",
    perms: "None"
};