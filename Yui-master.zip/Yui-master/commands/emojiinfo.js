const Discord = require("discord.js");
const moment = require("moment");


module.exports.run = async (bot, message) => {
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    if (!message.guild.iconURL) return Embeds.missing(message.channel, "If you want to execute this command, the server will need an icon.");

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter an emoji.");

    var Emote = message.args.join(" ");

    if (Emote) {

        if (message.guild.emojis.find(emoji => emoji.name === Emote)) {

            var successEmbed = new Discord.RichEmbed()

                .setColor(message.vars.embedRandom)
                .setThumbnail(message.guild.emojis.find(emoji => emoji.name === Emote).url)
                .setFooter(message.guild.name, message.guild.iconURL)
                .setTimestamp()
                .addField("Name", `${message.guild.emojis.find(emoji => emoji.name === Emote).name}`, true)
                .addField("ID", `*${message.guild.emojis.find(emoji => emoji.name === Emote).id}*`, true)
                .addField("Created at", `${moment(message.guild.emojis.find(emoji => emoji.name === Emote).createdAt).format("dddd, MMMM Do YYYY, HH:mm:ss")}`, true);

            message.channel.send(successEmbed);

        } else {
            Embeds.error(message.channel, "This emoji does not exist on the server.");
        }
    }
};

module.exports.help = {
    name: "emojiinfo",
    desc: "This command gives you Informations about a specific emoji.",
    usage: "emojiinfo [emojiname]",
    perms: "None"
};