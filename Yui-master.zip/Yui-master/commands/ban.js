const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
  message.delete();
  let BotSettings = bot.settings;
  let Embeds = bot.embeds;

  try {
    if (message.author.id === BotSettings.OwnerID || message.member.hasPermission("BAN_MEMBERS")) {

      let member = message.mentions.members.first() || message.guild.members.get(message.args[0]);

      if (!message.guild.member(bot.user.id).hasPermission("BAN_MEMBERS")) return Embeds.error(message.channel, "I do not have permissions to ban members on this guild.");

      if (!member) return Embeds.missing(message.channel, "Please enter a member that is on the server.");

      if (member.hasPermission("ADMINISTRATOR") || member.hasPermission("BAN_MEMBERS")) return Embeds.error(message.channel, "This member is not banable.");

      let reason = message.args.slice(1).join(" ");

      if (!reason) return Embeds.missing(message.channel, "Please give a reason!");

      if (member.id === BotSettings.OwnerID) return Embeds.error(message.channel, "The Developer cannot be banned!");

      await member.ban({
        reason: reason
      });

      var successEmbed = new Discord.RichEmbed()

        .setColor(message.vars.embedRandom)
        .setDescription(`**${member.user.username}**#${member.user.discriminator} was banned off the server for **${reason}**`);

      message.channel.send(successEmbed);
    } else {
     Embeds.error(message.channel, "This command requires the following server rights: **Ban_Members**.")
    }
  } catch (error) {
    Embeds.error(message.channel, `Hm. Something went wrong.\n\n\`\`\`${error}\`\`\``)
  }
};

module.exports.help = {
  name: "ban",
  desc: "With this command you can ban a member of this server, as long as you and I have the permission to execute this action. \nRemember that i can't ban a member with a role equal or higher than my highest role.",
  usage: "ban [member/ID] [reason]",
  perms: "Ban_Members"
};