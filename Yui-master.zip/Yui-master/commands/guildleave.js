const Discord = require("discord.js");


module.exports.run = async (bot, message) => {
    message.delete();
    let BotSettings = bot.settings;
    let Embeds = bot.embeds;

    var successEmbed = new Discord.RichEmbed()
        .setColor(message.vars.embedRandom)
        .setDescription(`I left the following server: **${message.args.join(" ")}**`);

    if (message.args.length < 1) return Embeds.missing(message.channel, "Please enter a server.");

    if (message.author.id === BotSettings.OwnerID) {
        bot.guilds.get(bot.guilds.find(server => server.name === message.args.join(" ")).id).leave();
        message.channel.send(successEmbed);

    } else {
        let msgguild = await Embeds.dev(message.channel);
        setTimeout(async () => {
            msgguild.delete();
        }, 5000);
    }
};

module.exports.help = {
    name: "guildleave",
    desc: "Leaves the server you enter.",
    usage: "None",
    perms: "Developer Perms"
};