const sections = ["info-commands", "moderation-commands","no-category-commands"];

function makeVisible(section) {
    sections.forEach(function (entry) {
        let currentSection = document.getElementById(entry);
        let displayProperty = currentSection.style.display;

        if (entry === section && displayProperty !== 'block') {
            currentSection.style.display = 'block';
        } else {
            currentSection.style.display = 'none';
        }
    });
}