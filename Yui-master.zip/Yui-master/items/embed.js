const Discord = require("discord.js");


const COLORS = {
    error: "#a21018",
    missing: "#f1c40f",
};

module.exports = {
    error: (chan, cont) => {
        var embed = new Discord.RichEmbed()
            .setColor(COLORS.error)
            .setTitle("Command execution failed.")
            .setDescription(cont);


        return chan.send("", embed);
    },

    missing: (chan, cont) => {
        var embed = new Discord.RichEmbed()
            .setColor(COLORS.missing)
            .setTitle("Hm. Something is missing to execute this command.")
            .setDescription(cont);


        return chan.send("", embed);
    },

    dev: (chan) => {
        var embed = new Discord.RichEmbed()

        .setColor(COLORS.error)
        .setTitle("Command execution failed.")
        .setDescription("Only the Developer can execute this command.");

        return chan.send("", embed);
    },

    ev: (chan, color, title, cont, thumbnail, footer, image) => {
        
    }

}